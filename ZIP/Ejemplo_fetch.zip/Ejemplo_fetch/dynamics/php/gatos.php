<?php
$gatos = [  ["img"=>"gatito (2).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (3).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (4).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (5).jpg", "nombre"=>"gatitos preciosos"],
						["img"=>"gatito (6).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (7).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (8).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (9).jpg", "nombre"=>"gatitos bonitos"],
						["img"=>"gatito (10).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (11).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (12).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (13).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (14).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (15).jpg", "nombre"=>"gatitos chéveres"],
						["img"=>"gatito (16).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (17).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (18).jpg", "nombre"=>"gatitos"],
						["img"=>"gatito (19).jpg", "nombre"=>"gatitos"]
					];
echo json_encode($gatos);
?>
